class ClickpayPaymentResponse {
  ClickpayPaymentResponse();

  ClickpayPaymentResponse.fromJson(dynamic json);
}
