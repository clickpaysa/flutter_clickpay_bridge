const String baseUrl = "https://ammarelgml-freebieticket.mocklab.io/";

const String epGetEvents = "events";
const String epGetUpcomingEvents = "upComingEvents";