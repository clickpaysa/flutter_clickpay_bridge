class ClickpayPaymentRequest {
  final double amount;
  final String currency;
  final String countryCode;

  ClickpayPaymentRequest(this.amount, this.currency, this.countryCode);
}
