import 'package:flutter_clickpay_bridge/BaseBillingShippingInfo.dart';
import 'package:flutter_clickpay_bridge/IOSThemeConfiguration.dart';
import 'package:flutter_clickpay_bridge/PaymentSdkConfigurationDetails.dart';
import 'package:flutter_clickpay_bridge/PaymentSdkLocale.dart';
import 'package:flutter_clickpay_bridge/PaymentSdkTokeniseType.dart';
import 'package:ticket_app/presentation/resources/asset_images.dart';

import '../network/requests/clickpay_payment_request.dart';

class ClickpayService {
  final billingInfo = BillingDetails(
    'John Smith',
    'johnsmith@gmail.com',
    '848484848484',
    'addressLine 1',
    'AE',
    'Dubai',
    'state',
    '12325',
  );

  final shippingInfo = ShippingDetails(
    'John Smith',
    'johnsmith@gmail.com',
    '848484848484',
    'addressLine 1',
    'AE',
    'Dubai',
    'state',
    '12325',
  );

  configPayment({required ClickpayPaymentRequest clickpayPaymentRequest}) {
    var configuration = PaymentSdkConfigurationDetails(
      profileId: '*PROFILE ID*',
      serverKey: '*SERVER kEY*',
      clientKey: '*CLIENT KEY*',
      cartId: "*CART ID*",
      cartDescription: "cart desc",
      merchantName: "merchant name",
      screentTitle: "Pay with Card",
      locale: PaymentSdkLocale.EN,
      amount: clickpayPaymentRequest.amount,
      currencyCode: clickpayPaymentRequest.currency,
      merchantCountryCode: clickpayPaymentRequest.countryCode,
      billingDetails: billingInfo,
    );

    var theme = IOSThemeConfigurations();
    theme.logoImage = AssetImages.appLogo;

    configuration.iOSThemeConfigurations = theme;

    configuration.showBillingInfo = false;
    configuration.showShippingInfo = false;
    configuration.tokeniseType = PaymentSdkTokeniseType.MERCHANT_MANDATORY;
    return configuration;
  }
}
