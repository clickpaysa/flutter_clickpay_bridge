const double dotRadius = 5;
const double dotSpacing = 15;

enum ConnectionStates {
  loading,
  timeout,
  connected,
  error,
}
