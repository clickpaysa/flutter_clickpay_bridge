class NewCardViewModel {}
