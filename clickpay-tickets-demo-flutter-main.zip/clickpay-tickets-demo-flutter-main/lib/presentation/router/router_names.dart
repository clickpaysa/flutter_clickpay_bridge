class RouterNames {
  static const String mainRoute = '/';
  static const String eventDetailsRoute = '/eventDetails';
  static const String paymentRoute = '/payment';
}
